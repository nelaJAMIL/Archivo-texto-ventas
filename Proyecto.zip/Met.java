/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventas;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.StringJoiner;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Windows 10
 */
public class Met {

    /**
     *
     * @param i
     */
    static void eliminar(int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   Vector vControl=new Vector();
   
    public void guardar(Productos unproducto) {
        vControl.addElement(unproducto);
                
    }
    public void eliminar(Productos ps) {
        vControl.removeElement(ps);
    }
     public void guardarArchivo(Productos producto){
    
   try{
    

       FileWriter fw=new FileWriter("productos.txt", true);
       BufferedWriter bw=new BufferedWriter(fw);
       PrintWriter pw=new PrintWriter(bw);
       
        pw.print("| "+ producto.getNombre());
         
         pw.print("| "+producto.getCodigo());
         
          pw.close();
   }   catch (Exception e) { 
       JOptionPane.showMessageDialog(null, e);
   }}
public DefaultTableModel Control()  {
    Vector cabeceras=new Vector();
   
    cabeceras.addElement("Nombre");
    cabeceras.addElement("tipo");
    cabeceras.addElement("Codigo");
    
    DefaultTableModel mTABLA=new DefaultTableModel(cabeceras, 0);
    
    try {
        FileReader fr=new FileReader("productos.txt");
        BufferedReader br=new BufferedReader (fr);
        String d;
      
            while((d= br.readLine())!=null){
                StringTokenizer dato=new StringTokenizer(d,"|");
                Vector x=new  Vector ();
                
                while(dato.hasMoreTokens()){
                    x.addElement(dato.nextToken());
            }
            mTABLA.addRow(x);
         
  }
        
                
    } catch (Exception e) {
           JOptionPane.showMessageDialog(null, e);


}
return mTABLA;   
}

//*public void tip(JComboBox Tiposs){
//Tiposs.removeAllItems();
//for(int x=10 ; x<60 ; x++){
// Tiposs.addItem(x);
public void Eliminar(JTable tabla, JTextField codigoss) {
//Eliminación visual de la tabla
	DefaultTableModel model = (DefaultTableModel)tabla.getModel();
	
	for (int x = 0; x < model.getRowCount(); x++) {
		
		if(((String)model.getValueAt(x, 0)).equals(codigoss.getText())) {	
			model.removeRow(x);
			break;
			
		}
	}
	//Limpieza del archivo .txt
	
	try {
		PrintWriter writer = new PrintWriter("productos.txt");
		writer.print("");
		writer.close();
	} catch (Exception e) {
		JOptionPane.showMessageDialog(null,"Ocurrió un problema"+ e.toString());
	}
	
	//Creación de los nuevos registros luego de la eliminación
	
	try (BufferedWriter bw = new BufferedWriter(new FileWriter(new File("productos.txt")))) {
		StringJoiner joiner = new StringJoiner(",");
		
		for (int col = 0; col < tabla.getColumnCount(); col++) {
			joiner.add(tabla.getColumnName(col));
		}
		
		System.out.println(joiner.toString());
		bw.write(joiner.toString());
		bw.newLine();
		
		for (int row = 0; row < tabla.getRowCount(); row++) {
			 joiner = new StringJoiner(",");		
			for (int col = 0; col < tabla.getColumnCount(); col++) {
				
				Object obj = tabla.getValueAt(row, col);
				String value = obj == null ? "null" :obj.toString();
				joiner.add(value);
				
			}
			
			
			bw.write(joiner.toString());
			bw.newLine();
			JOptionPane.showMessageDialog(null, "Se eliminó correctamente");
		}

		
	} catch (Exception e) {
		JOptionPane.showMessageDialog(null, "Ocurrio un error");
	}
	
	
	
}
}
 

   
        
    

    
