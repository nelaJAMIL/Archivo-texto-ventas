
package ventas;

import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Windows 10
 */
public class LimpiarC {

    /**
     * @param args the command line arguments
     */
    public void Limpiar(JPanel panel) {
        for(Object o: panel.getComponents()){
            if(o instanceof JTextField){
                ((JTextField)o).setText("");
            }
        }
    }
    
}
