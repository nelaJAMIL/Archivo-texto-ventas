/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventas;



/**
 *
 * @author Windows 10
 */
public class Productos {

    private String Codigo;
     private String Nombre;
     private String Descripcion;
      private String precioV;
     private String precioC;
      private String fecha;
     private String Estatu;
     private String Stock;

    public String getStock() {
        return Stock;
    }

    public void setStock(String Stock) {
        this.Stock = Stock;
    }
 
    public String getCodigo() {
        return Codigo;
    }

    public void setCodigo(String Codigo) {
        this.Codigo = Codigo;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }

    public String getPrecioV() {
        return precioV;
    }

    public void setPrecioV(String precioV) {
        this.precioV = precioV;
    }

    public String getPrecioC() {
        return precioC;
    }

    public void setPrecioC(String precioC) {
        this.precioC = precioC;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getEstatu() {
        return Estatu;
    }

    public void setEstatu(String Estatu) {
        this.Estatu = Estatu;
    }

   
    
     
      public Productos (){
      }

       

    Productos(String data) {
        String[] dataArr = data.split(",");
        this.Codigo= dataArr[0];
        this.Nombre = dataArr[1];
        this.Descripcion = dataArr[2];
        this.precioV = dataArr[3];
        this.Stock= dataArr[4];
        this.precioC = dataArr[5];
        this.fecha = dataArr[6];
        this.Estatu= dataArr[7];
    }
public String toString() {
        return (this.Codigo + "," + this.Nombre + "," + this.Descripcion + "," + this.precioV+this.Stock + "," + this.precioC + "," + this.fecha + "," + this.Estatu).toLowerCase();
    }

    void setEstatu() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void setCodigo() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void setNombre() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


}