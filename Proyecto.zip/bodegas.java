/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventas;

/**
 *
 * @author Windows 10
 */
public class bodegas {

    private String Codigo;
     private String Nombre;
     private String Descrip;
      private String BodV;
       private String EstB;

    public String getCodigo() {
        return Codigo;
    }

    public void setCodigo(String Codigo) {
        this.Codigo = Codigo;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getDescrip() {
        return Descrip;
    }

    public void setDescrip(String Descrip) {
        this.Descrip = Descrip;
    }

    public String getBodV() {
        return BodV;
    }

    public void setBodV(String BodV) {
        this.BodV = BodV;
    }

    public String getEstB() {
        return EstB;
    }

    public void setEstB(String EstB) {
        this.EstB = EstB;
    }
     
}
    