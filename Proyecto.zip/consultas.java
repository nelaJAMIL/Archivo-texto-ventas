/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventas;

/**
 *
 * @author Windows 10
 */
public class consultas {

   private String Codigo1;
     private String Nombre1;
     private String Descripcion1;
      private String precioV1;
     private String cantidad;
     private String Descuento;
private String importe;
private String stoc;
private String cliente;
private String totalc;
private String ganaa;

    public String getTotalc() {
        return totalc;
    }

    public void setTotalc(String totalc) {
        this.totalc = totalc;
    }

    public String getGanaa() {
        return ganaa;
    }

    public void setGanaa(String ganaa) {
        this.ganaa = ganaa;
    }

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }
    public String getStoc() {
        return stoc;
    }

    public void setStoc(String stoc) {
        this.stoc = stoc;
    }
    public String getDescuento() {
        return Descuento;
    }

    public void setDescuento(String Descuento) {
        this.Descuento = Descuento;
    }
      

    public String getCodigo1() {
        return Codigo1;
    }

    public void setCodigo1(String Codigo1) {
        this.Codigo1 = Codigo1;
    }

    public String getNombre1() {
        return Nombre1;
    }

    public void setNombre1(String Nombre1) {
        this.Nombre1 = Nombre1;
    }

    public String getDescripcion1() {
        return Descripcion1;
    }

    public void setDescripcion1(String Descripcion1) {
        this.Descripcion1 = Descripcion1;
    }

    public String getPrecioV1() {
        return precioV1;
    }

    public void setPrecioV1(String precioV1) {
        this.precioV1 = precioV1;
    }

    public String getCantidad() {
        return cantidad;
    }

    public void setCantidad(String cantidad) {
        this.cantidad = cantidad;
    }

    public String getImporte() {
        return importe;
    }

    public void setImporte(String importe) {
        this.importe = importe;
    }
    public static void main(String[] args) {
        // TODO code application logic here
    }

    
    
    
}
