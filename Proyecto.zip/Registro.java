/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventas;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;





/**
 *
 * @author Windows 10
 */
public class Registro extends javax.swing.JDialog {
    
DefaultTableModel model=new DefaultTableModel();
    int filas;
    boolean isFound = false;
    private void Lis(){
         model.addColumn("Codigo del producto.");
         model.addColumn("Nombre del producto.");
         model.addColumn("Descripcion del producto.");
         model.addColumn("Precio de venta.");
         model.addColumn("Productos en tienda.");
         model.addColumn("Fecha de ingreso.");
         model.addColumn("Precio de compra.");
         model.addColumn("Estado del producto.");
         
         tabla.setModel(model);
     }
    private void us(){
        int filass=tabla.getSelectedRow();
        model.setValueAt(co.getText(),filas,0);
        
        
    }
    private final String ruta=System.getProperties().getProperty("user.dir");
    public Registro()  {
        initComponents();
        Lis();
        
        
    }
    

    
    
    
 
    
    

    
    

    
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        modificar = new javax.swing.JButton();
        guardar = new javax.swing.JButton();
        mostrar = new javax.swing.JButton();
        eliminar = new javax.swing.JButton();
        Es = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        no = new javax.swing.JTextField();
        co = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        uno = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        dos = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        tres = new javax.swing.JTextField();
        cuatro = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        stock = new javax.swing.JTextField();
        bus = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Tabla de registro de productos.");
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setPreferredSize(new java.awt.Dimension(1000, 600));

        modificar.setText("Modificar dato.");
        modificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modificarActionPerformed(evt);
            }
        });

        guardar.setText("Guardar datos.");
        guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guardarActionPerformed(evt);
            }
        });

        mostrar.setText("Mostrar tabla.");
        mostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mostrarActionPerformed(evt);
            }
        });

        eliminar.setText("Eliminar dato.");
        eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarActionPerformed(evt);
            }
        });

        Es.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Activo ", "Inactivo" }));
        Es.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EsActionPerformed(evt);
            }
        });

        jLabel1.setBackground(new java.awt.Color(204, 51, 255));
        jLabel1.setFont(new java.awt.Font("Dubai Medium", 2, 18)); // NOI18N
        jLabel1.setText(" Tabla de informacion de productos.");

        no.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                noActionPerformed(evt);
            }
        });

        co.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                coActionPerformed(evt);
            }
        });

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Codigo", "Nombre del producto", "Marca ", "Tipo", "Unidad de medida", "Estatus", "Title 7", "Title 8"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tabla.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_LAST_COLUMN);
        tabla.setColumnSelectionAllowed(true);
        tabla.setDropMode(javax.swing.DropMode.ON_OR_INSERT_ROWS);
        tabla.setGridColor(new java.awt.Color(0, 153, 153));
        tabla.setSelectionBackground(new java.awt.Color(51, 204, 255));
        tabla.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tabla.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tabla.addContainerListener(new java.awt.event.ContainerAdapter() {
            public void componentRemoved(java.awt.event.ContainerEvent evt) {
                tablaComponentRemoved(evt);
            }
        });
        tabla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabla);
        tabla.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        if (tabla.getColumnModel().getColumnCount() > 0) {
            tabla.getColumnModel().getColumn(5).setCellEditor(new javax.swing.DefaultCellEditor(Es)
            );
        }
        tabla.getAccessibleContext().setAccessibleParent(tabla);

        jLabel2.setFont(new java.awt.Font("Courier New", 1, 12)); // NOI18N
        jLabel2.setText("Nombre del producto.");

        jLabel3.setFont(new java.awt.Font("Courier New", 1, 12)); // NOI18N
        jLabel3.setText("Descripcion del producto.");

        jLabel4.setFont(new java.awt.Font("Courier New", 1, 12)); // NOI18N
        jLabel4.setText("Codigo del producto.");

        jButton1.setText("Regresar al menu.");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Courier New", 1, 12)); // NOI18N
        jLabel5.setText("Precio venta del producto.");

        jLabel6.setFont(new java.awt.Font("Courier New", 1, 12)); // NOI18N
        jLabel6.setText("Fecha de ingreso.");

        jLabel7.setFont(new java.awt.Font("Courier New", 1, 12)); // NOI18N
        jLabel7.setText("Estado del producto.");

        jLabel8.setFont(new java.awt.Font("Courier New", 1, 12)); // NOI18N
        jLabel8.setText("Precio compra del producto.");

        tres.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tresActionPerformed(evt);
            }
        });

        cuatro.setText(" ");

        jLabel9.setFont(new java.awt.Font("Courier New", 1, 12)); // NOI18N
        jLabel9.setText("Productos en tienda.");

        stock.setText(" ");

        bus.setText("Actualizar tabla.");
        bus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                busActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(65, 65, 65))
            .addGroup(layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1061, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(25, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel7))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(guardar))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(co, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(no, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(uno, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Es, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 262, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel6)
                                        .addGap(88, 88, 88)
                                        .addComponent(cuatro, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel9))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(dos, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(stock, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel8)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(tres, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(150, 150, 150))))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(353, 353, 353)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(modificar)
                                .addGap(18, 18, 18)
                                .addComponent(bus)
                                .addGap(18, 18, 18)
                                .addComponent(eliminar))
                            .addComponent(mostrar))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(co, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(dos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(no, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(stock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(uno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(tres, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(Es, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cuatro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                .addComponent(guardar)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 262, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(mostrar)
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(eliminar)
                    .addComponent(jButton1)
                    .addComponent(modificar)
                    .addComponent(bus))
                .addGap(32, 32, 32))
        );

        getAccessibleContext().setAccessibleName("Tabla de control de productos");

        setSize(new java.awt.Dimension(1136, 740));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarActionPerformed
       Productos obj=new Productos();
        obj.setCodigo(co.getText());
        obj.setNombre(no.getText());
        obj.setDescripcion(uno.getText());
        obj.setPrecioV(dos.getText());
        obj.setStock(stock.getText());
        obj.setPrecioC(tres.getText());
        obj.setFecha(cuatro.getText());
       
        obj.setEstatu((String)Es.getSelectedItem());
        Object[] fila=new Object[8];
        fila[0]=obj.getCodigo();
        fila[1]=obj.getNombre();
        fila[2]=obj.getDescripcion();
        fila[3]=obj.getPrecioV();
        fila[4]=obj.getStock();
        fila[5]=obj.getPrecioC();
        fila[6]=obj.getFecha();
        fila[7]=obj.getEstatu();
        int[] rows = tabla.getSelectedRows();
        try {
           
            FileWriter fw = new FileWriter("E:\\usuario\\produc.txt");
           PrintWriter pw=new PrintWriter(fw);
      
          for(int i=0;i<rows.length;i++){
     model.removeRow(rows[i]-i);
        }pw.print(obj.getCodigo()+"/"+obj.getNombre()+"/"+obj.getDescripcion()+"/"+obj.getPrecioV()+"/"+obj.getStock()+"/"+obj.getFecha()+"/"+obj.getPrecioC()+"/"+obj.getEstatu()+"/\n");
           pw.close();
            
           JOptionPane.showMessageDialog(null,"El dato se eliminado con exito.");
             } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Ha habido un error, vuelva a intentarlo.");
        
            
       
         } 
       
    }//GEN-LAST:event_eliminarActionPerformed

    private void modificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modificarActionPerformed
 String search_id = co.getText();
        String nombre = no.getText();
        String Descrip =uno.getText();
        String preciov = dos.getText();
         String product = stock.getText();
        String precioC = tres.getText();
        String fechaa =cuatro.getText();
        String Estado = ((String)Es.getSelectedItem());

        ArrayList<String> Productos = new ArrayList<>();

        try {
                try (FileReader fr = new FileReader("E:\\usuario\\produc.txt")) {
                    Scanner br = new Scanner(fr);
                    String data;
                    String[] tempUser;

                    while ((data = br.nextLine()) != null) {
                        tempUser = data.split(",");
                        if (tempUser[0].equals(search_id)) {
                            
                        
                            Productos.add(
                                    
                             tempUser[0]+","+
                                   nombre  +","+
                                   Descrip +","+
                                   preciov +","+
                                   product +","+
                                   precioC +","+
                                   fechaa  +","+
                                   Estado);
                            
                       
                    }else{
                            Productos.add(data);
                        }
                    }
                    fr.close();
} catch (Exception x) {
    
    } }catch (Exception x) {
    }
                try (PrintWriter pw = new PrintWriter("E:\\usuario\\produc.txt")) {
                  
                   for(String str: Productos){
                       
                       pw.println(str);
                       
                   }
                   pw.close();
     } catch (Exception x) {
       
     }
            
            
        
   
    
    }//GEN-LAST:event_modificarActionPerformed

    private void guardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guardarActionPerformed
    Productos obj=new Productos();
        obj.setCodigo(co.getText());
        obj.setNombre(no.getText());
        obj.setDescripcion(uno.getText());
        obj.setPrecioV(dos.getText());
        obj.setStock(stock.getText());
        obj.setPrecioC(tres.getText());
        obj.setFecha(cuatro.getText());
       
        obj.setEstatu((String)Es.getSelectedItem());
        
        Object[] fila=new Object[8];
        fila[0]=obj.getCodigo();
        fila[1]=obj.getNombre();
        fila[2]=obj.getDescripcion();
        fila[3]=obj.getPrecioV();
        fila[4]=obj.getStock();
        fila[5]=obj.getPrecioC();
        fila[6]=obj.getFecha();
        fila[7]=obj.getEstatu();
        
        model.addRow(fila);
        try{
            FileWriter fw;
            PrintWriter pw;
           fw=new FileWriter("E:\\usuario\\produc.txt", true); 
           pw=new PrintWriter(fw);
           pw.print(obj.getCodigo()+","+obj.getNombre()+","+obj.getDescripcion()+","+obj.getPrecioV()+","+obj.getStock()+","+obj.getFecha()+","+obj.getPrecioC()+","+obj.getEstatu()+"\n");
           pw.close();
          JOptionPane.showMessageDialog(null,"Los datos se han guardado de forma exitosa.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Ha habido un error, vuelva a intentarlo.");
        }  
    }//GEN-LAST:event_guardarActionPerformed

    private void mostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mostrarActionPerformed

            File archivo = null;
      FileReader fr = null;
      BufferedReader br = null;

      try {
         // Apertura del fichero y creacion de BufferedReader para poder
         
         archivo = new File ("E:\\usuario\\produc.txt");
         fr = new FileReader (archivo);
         br = new BufferedReader(fr);
           
           
            Object[] filass = br.lines().toArray();
            
            
            for(int i = 0; i < filass.length; i++)
            {
                String line = filass[i].toString().trim();
                String[] dataRow = line.split(",");
                model.addRow(dataRow);
            }
         
         
           
         
           br.close();
           } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Ha habido un error, vuelva a intentarlo.");
           }
    }//GEN-LAST:event_mostrarActionPerformed

    private void coActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_coActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_coActionPerformed

    private void tablaComponentRemoved(java.awt.event.ContainerEvent evt) {//GEN-FIRST:event_tablaComponentRemoved
        // TODO add your handling code here:
    }//GEN-LAST:event_tablaComponentRemoved

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

  dispose();
       
      
       
    }//GEN-LAST:event_jButton1ActionPerformed

    private void noActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_noActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_noActionPerformed

    private void tablaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaMouseClicked
       int select=tabla.getSelectedRow();
        co.setText(tabla.getValueAt(select,0).toString());
        no.setText(tabla.getValueAt(select,1).toString());
        uno.setText(tabla.getValueAt(select,2).toString());
        dos.setText(tabla.getValueAt(select,3).toString());
        stock.setText(tabla.getValueAt(select,4).toString());
        tres.setText(tabla.getValueAt(select,5).toString());
        cuatro.setText(tabla.getValueAt(select,6).toString());
        Es.setSelectedItem(tabla.getValueAt(select,7).toString());
        filas=select;
        
    }//GEN-LAST:event_tablaMouseClicked

    private void tresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tresActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tresActionPerformed

    private void EsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EsActionPerformed

    private void busActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_busActionPerformed
       
        Productos obj=new Productos();
        obj.setCodigo(co.getText());
        obj.setNombre(no.getText());
        obj.setDescripcion(uno.getText());
        obj.setPrecioV(dos.getText());
        obj.setStock(stock.getText());
        obj.setPrecioC(tres.getText());
        obj.setFecha(cuatro.getText());
       
        obj.setEstatu((String)Es.getSelectedItem());
        
        Object[] fila=new Object[8];
        fila[0]=obj.getCodigo();
        fila[1]=obj.getNombre();
        fila[2]=obj.getDescripcion();
        fila[3]=obj.getPrecioV();
        fila[4]=obj.getStock();
        fila[5]=obj.getPrecioC();
        fila[6]=obj.getFecha();
        fila[7]=obj.getEstatu();

    for (int i=0;i<tabla.getColumnCount();i++){
            model.setValueAt(fila[i], filas, i);
    }
    }//GEN-LAST:event_busActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Registro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Registro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Registro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Registro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
       
               
                java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Registro().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> Es;
    private javax.swing.JButton bus;
    private javax.swing.JTextField co;
    private javax.swing.JTextField cuatro;
    private javax.swing.JTextField dos;
    private javax.swing.JButton eliminar;
    private javax.swing.JButton guardar;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton modificar;
    private javax.swing.JButton mostrar;
    private javax.swing.JTextField no;
    private javax.swing.JTextField stock;
    public static javax.swing.JTable tabla;
    private javax.swing.JTextField tres;
    private javax.swing.JTextField uno;
    // End of variables declaration//GEN-END:variables

    
        }
