/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventas;


public class factura {

    private String cliente;
    private String fechav;
    private String Nit;
     private String subt;
    private String impuesto;
    private String totalc;
private String vendedor;

    public String getVendedor() {
        return vendedor;
    }

    public void setVendedor(String vendedor) {
        this.vendedor = vendedor;
    }
    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public String getFechav() {
        return fechav;
    }

    public void setFechav(String fechav) {
        this.fechav = fechav;
    }

    public String getNit() {
        return Nit;
    }

    public void setNit(String Nit) {
        this.Nit = Nit;
    }

    public String getSubt() {
        return subt;
    }

    public void setSubt(String subt) {
        this.subt = subt;
    }

    public String getImpuesto() {
        return impuesto;
    }

    public void setImpuesto(String impuesto) {
        this.impuesto = impuesto;
    }

    public String getTotalc() {
        return totalc;
    }

    public void setTotalc(String totalc) {
        this.totalc = totalc;
    }
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
